var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "1800",
        "ok": "1800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21068",
        "ok": "21068",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1773",
        "ok": "1773",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1820",
        "ok": "1820",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1065",
        "ok": "1065",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2755",
        "ok": "2755",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5210",
        "ok": "5210",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6244",
        "ok": "6244",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 717,
    "percentage": 40
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 261,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 822,
    "percentage": 46
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.557",
        "ok": "18.557",
        "ko": "-"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1795",
        "ok": "1795",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "820",
        "ok": "820",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "402",
        "ok": "402",
        "ko": "-"
    },
    "percentiles1": {
        "total": "812",
        "ok": "812",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1092",
        "ok": "1092",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1518",
        "ok": "1518",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1772",
        "ok": "1772",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 24,
    "percentage": 48
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 19,
    "percentage": 38
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 7,
    "percentage": 14
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4143",
        "ok": "4143",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1817",
        "ok": "1817",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1249",
        "ok": "1249",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2359",
        "ok": "2359",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2844",
        "ok": "2844",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3445",
        "ok": "3445",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3970",
        "ok": "3970",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 17,
    "percentage": 34
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 30,
    "percentage": 60
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2250",
        "ok": "2250",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "582",
        "ok": "582",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "percentiles1": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "percentiles2": {
        "total": "829",
        "ok": "829",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1266",
        "ok": "1266",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1544",
        "ok": "1544",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 109,
    "percentage": 73
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 31,
    "percentage": 21
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10,
    "percentage": 7
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.546",
        "ok": "1.546",
        "ko": "-"
    }
}
    },"req_solid-auth-clie-301ec": {
        type: "REQUEST",
        name: "solid-auth-client.bundle.js",
path: "solid-auth-client.bundle.js",
pathFormatted: "req_solid-auth-clie-301ec",
stats: {
    "name": "solid-auth-client.bundle.js",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2829",
        "ok": "2829",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1159",
        "ok": "1159",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "633",
        "ok": "633",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1086",
        "ok": "1086",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1637",
        "ok": "1637",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2213",
        "ok": "2213",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2774",
        "ok": "2774",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 34,
    "percentage": 34
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 18,
    "percentage": 18
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 48,
    "percentage": 48
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.031",
        "ok": "1.031",
        "ko": "-"
    }
}
    },"req_solid-css-8f91a": {
        type: "REQUEST",
        name: "solid.css",
path: "solid.css",
pathFormatted: "req_solid-css-8f91a",
stats: {
    "name": "solid.css",
    "numberOfRequests": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2168",
        "ok": "2168",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "684",
        "ok": "684",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles1": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1035",
        "ok": "1035",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1543",
        "ok": "1543",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2035",
        "ok": "2035",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 95,
    "percentage": 63
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 30,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 25,
    "percentage": 17
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.546",
        "ok": "1.546",
        "ko": "-"
    }
}
    },"req_auth-buttons-js-47a35": {
        type: "REQUEST",
        name: "auth-buttons.js",
path: "auth-buttons.js",
pathFormatted: "req_auth-buttons-js-47a35",
stats: {
    "name": "auth-buttons.js",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "170",
        "ok": "170",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2207",
        "ok": "2207",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "882",
        "ok": "882",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "465",
        "ok": "465",
        "ko": "-"
    },
    "percentiles1": {
        "total": "839",
        "ok": "839",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1206",
        "ok": "1206",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1593",
        "ok": "1593",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2126",
        "ok": "2126",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 47,
    "percentage": 47
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 28,
    "percentage": 28
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 25,
    "percentage": 25
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.031",
        "ok": "1.031",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "156",
        "ok": "156",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2579",
        "ok": "2579",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "868",
        "ok": "868",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "543",
        "ok": "543",
        "ko": "-"
    },
    "percentiles1": {
        "total": "774",
        "ok": "774",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1240",
        "ok": "1240",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1862",
        "ok": "1862",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2260",
        "ok": "2260",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 27,
    "percentage": 54
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 16,
    "percentage": 32
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1503",
        "ok": "1503",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "636",
        "ok": "636",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "380",
        "ok": "380",
        "ko": "-"
    },
    "percentiles1": {
        "total": "681",
        "ok": "681",
        "ko": "-"
    },
    "percentiles2": {
        "total": "853",
        "ok": "853",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1226",
        "ok": "1226",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1469",
        "ok": "1469",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 33,
    "percentage": 66
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 26
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-2-redir-733ac": {
        type: "REQUEST",
        name: "request_2 Redirect 1",
path: "request_2 Redirect 1",
pathFormatted: "req_request-2-redir-733ac",
stats: {
    "name": "request_2 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2127",
        "ok": "2127",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "889",
        "ok": "889",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "563",
        "ok": "563",
        "ko": "-"
    },
    "percentiles1": {
        "total": "943",
        "ok": "943",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1292",
        "ok": "1292",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1776",
        "ok": "1776",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2016",
        "ok": "2016",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 23,
    "percentage": 46
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 17,
    "percentage": 34
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2486",
        "ok": "2486",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "949",
        "ok": "949",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "524",
        "ok": "524",
        "ko": "-"
    },
    "percentiles1": {
        "total": "926",
        "ok": "926",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1277",
        "ok": "1277",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1779",
        "ok": "1779",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2365",
        "ok": "2365",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 21,
    "percentage": 42
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 22
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 18,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-3-redir-2cb6e": {
        type: "REQUEST",
        name: "request_3 Redirect 1",
path: "request_3 Redirect 1",
pathFormatted: "req_request-3-redir-2cb6e",
stats: {
    "name": "request_3 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "340",
        "ok": "340",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles1": {
        "total": "308",
        "ok": "308",
        "ko": "-"
    },
    "percentiles2": {
        "total": "455",
        "ok": "455",
        "ko": "-"
    },
    "percentiles3": {
        "total": "675",
        "ok": "675",
        "ko": "-"
    },
    "percentiles4": {
        "total": "785",
        "ok": "785",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 49,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-3-redir-9f15c": {
        type: "REQUEST",
        name: "request_3 Redirect 2",
path: "request_3 Redirect 2",
pathFormatted: "req_request-3-redir-9f15c",
stats: {
    "name": "request_3 Redirect 2",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "89",
        "ok": "89",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2162",
        "ok": "2162",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "953",
        "ok": "953",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "530",
        "ok": "530",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1046",
        "ok": "1046",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1277",
        "ok": "1277",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1738",
        "ok": "1738",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2058",
        "ok": "2058",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 16,
    "percentage": 32
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 32
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 18,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-3-redir-08bb3": {
        type: "REQUEST",
        name: "request_3 Redirect 3",
path: "request_3 Redirect 3",
pathFormatted: "req_request-3-redir-08bb3",
stats: {
    "name": "request_3 Redirect 3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2575",
        "ok": "2575",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "954",
        "ok": "954",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "555",
        "ok": "555",
        "ko": "-"
    },
    "percentiles1": {
        "total": "948",
        "ok": "948",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1348",
        "ok": "1348",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1748",
        "ok": "1748",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2364",
        "ok": "2364",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 19,
    "percentage": 38
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 28
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 17,
    "percentage": 34
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "401",
        "ok": "401",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21068",
        "ok": "21068",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4837",
        "ok": "4837",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3602",
        "ok": "3602",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4984",
        "ok": "4984",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5518",
        "ok": "5518",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10696",
        "ok": "10696",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17698",
        "ok": "17698",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 8
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 43,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_mash-css-d5713": {
        type: "REQUEST",
        name: "mash.css",
path: "mash.css",
pathFormatted: "req_mash-css-d5713",
stats: {
    "name": "mash.css",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1119",
        "ok": "1119",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "523",
        "ok": "523",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "278",
        "ok": "278",
        "ko": "-"
    },
    "percentiles1": {
        "total": "490",
        "ok": "490",
        "ko": "-"
    },
    "percentiles2": {
        "total": "726",
        "ok": "726",
        "ko": "-"
    },
    "percentiles3": {
        "total": "993",
        "ok": "993",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1119",
        "ok": "1119",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 42,
    "percentage": 84
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 8,
    "percentage": 16
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_mashlib-min-js-40849": {
        type: "REQUEST",
        name: "mashlib.min.js",
path: "mashlib.min.js",
pathFormatted: "req_mashlib-min-js-40849",
stats: {
    "name": "mashlib.min.js",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6279",
        "ok": "6279",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3885",
        "ok": "3885",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1549",
        "ok": "1549",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4402",
        "ok": "4402",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5115",
        "ok": "5115",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5667",
        "ok": "5667",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5994",
        "ok": "5994",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 6
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 46,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "13537",
        "ok": "13537",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4313",
        "ok": "4313",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2331",
        "ok": "2331",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4562",
        "ok": "4562",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5414",
        "ok": "5414",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7108",
        "ok": "7108",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11133",
        "ok": "11133",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 6
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 44,
    "percentage": 88
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "413",
        "ok": "413",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6086",
        "ok": "6086",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3836",
        "ok": "3836",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1601",
        "ok": "1601",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4462",
        "ok": "4462",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5046",
        "ok": "5046",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5490",
        "ok": "5490",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5899",
        "ok": "5899",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 8
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 45,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "437",
        "ok": "437",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6645",
        "ok": "6645",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3985",
        "ok": "3985",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1683",
        "ok": "1683",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4536",
        "ok": "4536",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5332",
        "ok": "5332",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5756",
        "ok": "5756",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6449",
        "ok": "6449",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 8
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 45,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "344",
        "ok": "344",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6245",
        "ok": "6245",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3960",
        "ok": "3960",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1676",
        "ok": "1676",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4553",
        "ok": "4553",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5331",
        "ok": "5331",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5637",
        "ok": "5637",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6049",
        "ok": "6049",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 8
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 46,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1295",
        "ok": "1295",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "474",
        "ok": "474",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "283",
        "ok": "283",
        "ko": "-"
    },
    "percentiles1": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "percentiles2": {
        "total": "664",
        "ok": "664",
        "ko": "-"
    },
    "percentiles3": {
        "total": "928",
        "ok": "928",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1224",
        "ok": "1224",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 45,
    "percentage": 90
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1309",
        "ok": "1309",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "514",
        "ok": "514",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "338",
        "ok": "338",
        "ko": "-"
    },
    "percentiles1": {
        "total": "409",
        "ok": "409",
        "ko": "-"
    },
    "percentiles2": {
        "total": "753",
        "ok": "753",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1213",
        "ok": "1213",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1275",
        "ok": "1275",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 39,
    "percentage": 78
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 8,
    "percentage": 16
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "510",
        "ok": "510",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5383",
        "ok": "5383",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3016",
        "ok": "3016",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1246",
        "ok": "1246",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3462",
        "ok": "3462",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3914",
        "ok": "3914",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4447",
        "ok": "4447",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4969",
        "ok": "4969",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 44,
    "percentage": 88
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "375",
        "ok": "375",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5272",
        "ok": "5272",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2922",
        "ok": "2922",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1205",
        "ok": "1205",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3329",
        "ok": "3329",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3795",
        "ok": "3795",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4390",
        "ok": "4390",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4855",
        "ok": "4855",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 43,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "385",
        "ok": "385",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4085",
        "ok": "4085",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2591",
        "ok": "2591",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1084",
        "ok": "1084",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3058",
        "ok": "3058",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3449",
        "ok": "3449",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3790",
        "ok": "3790",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4082",
        "ok": "4082",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6,
    "percentage": 12
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 41,
    "percentage": 82
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "495",
        "ok": "495",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5384",
        "ok": "5384",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3018",
        "ok": "3018",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1242",
        "ok": "1242",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3461",
        "ok": "3461",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3911",
        "ok": "3911",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4455",
        "ok": "4455",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4972",
        "ok": "4972",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 43,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "517",
        "ok": "517",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5383",
        "ok": "5383",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3373",
        "ok": "3373",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1449",
        "ok": "1449",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4023",
        "ok": "4023",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4462",
        "ok": "4462",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4851",
        "ok": "4851",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5207",
        "ok": "5207",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 43,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "571",
        "ok": "571",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4533",
        "ok": "4533",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2968",
        "ok": "2968",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1130",
        "ok": "1130",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3420",
        "ok": "3420",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3729",
        "ok": "3729",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4393",
        "ok": "4393",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4505",
        "ok": "4505",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 6
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 44,
    "percentage": 88
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2050",
        "ok": "2050",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1006",
        "ok": "1006",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "444",
        "ok": "444",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1061",
        "ok": "1061",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1281",
        "ok": "1281",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1679",
        "ok": "1679",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1962",
        "ok": "1962",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 17,
    "percentage": 34
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 28
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 19,
    "percentage": 38
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    },"req_request-17-redi-ff1b4": {
        type: "REQUEST",
        name: "request_17 Redirect 1",
path: "request_17 Redirect 1",
pathFormatted: "req_request-17-redi-ff1b4",
stats: {
    "name": "request_17 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "116",
        "ok": "116",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19644",
        "ok": "19644",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2513",
        "ok": "2513",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2752",
        "ok": "2752",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2503",
        "ok": "2503",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2816",
        "ok": "2816",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4520",
        "ok": "4520",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13067",
        "ok": "13067",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 37,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.515",
        "ok": "0.515",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
