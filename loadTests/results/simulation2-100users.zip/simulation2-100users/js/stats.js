var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "2872",
        "ok": "2720",
        "ko": "152"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "38934",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "7055",
        "ok": "4096",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "14626",
        "ok": "7777",
        "ko": "1"
    },
    "percentiles1": {
        "total": "775",
        "ok": "732",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "3776",
        "ok": "3286",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "25734",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "27845",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1461,
    "percentage": 51
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 265,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 994,
    "percentage": 35
},
    "group4": {
    "name": "failed",
    "count": 152,
    "percentage": 5
},
    "meanNumberOfRequestsPerSecond": {
        "total": "12.221",
        "ok": "11.574",
        "ko": "0.647"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "474",
        "ok": "474",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "746",
        "ok": "746",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "615",
        "ok": "615",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "percentiles1": {
        "total": "613",
        "ok": "613",
        "ko": "-"
    },
    "percentiles2": {
        "total": "652",
        "ok": "652",
        "ko": "-"
    },
    "percentiles3": {
        "total": "703",
        "ok": "703",
        "ko": "-"
    },
    "percentiles4": {
        "total": "731",
        "ok": "731",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "100",
        "ok": "37",
        "ko": "63"
    },
    "minResponseTime": {
        "total": "597",
        "ok": "597",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "34114",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "41070",
        "ok": "8838",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "25391",
        "ok": "9658",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60000",
        "ok": "4844",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "60000",
        "ok": "9018",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "33568",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "34002",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 2
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 34,
    "percentage": 34
},
    "group4": {
    "name": "failed",
    "count": 63,
    "percentage": 63
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.157",
        "ko": "0.268"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "208",
        "ok": "208",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1467",
        "ok": "1467",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "percentiles1": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles2": {
        "total": "342",
        "ok": "342",
        "ko": "-"
    },
    "percentiles3": {
        "total": "799",
        "ok": "799",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1236",
        "ok": "1236",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 197,
    "percentage": 95
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.885",
        "ok": "0.885",
        "ko": "-"
    }
}
    },"req_solid-auth-clie-301ec": {
        type: "REQUEST",
        name: "solid-auth-client.bundle.js",
path: "solid-auth-client.bundle.js",
pathFormatted: "req_solid-auth-clie-301ec",
stats: {
    "name": "solid-auth-client.bundle.js",
    "numberOfRequests": {
        "total": "108",
        "ok": "108",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "165",
        "ok": "165",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1954",
        "ok": "1954",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "682",
        "ok": "682",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "459",
        "ok": "459",
        "ko": "-"
    },
    "percentiles1": {
        "total": "506",
        "ok": "506",
        "ko": "-"
    },
    "percentiles2": {
        "total": "900",
        "ok": "900",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1778",
        "ok": "1778",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1881",
        "ok": "1881",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 78,
    "percentage": 72
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 17,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.46",
        "ok": "0.46",
        "ko": "-"
    }
}
    },"req_solid-css-8f91a": {
        type: "REQUEST",
        name: "solid.css",
path: "solid.css",
pathFormatted: "req_solid-css-8f91a",
stats: {
    "name": "solid.css",
    "numberOfRequests": {
        "total": "208",
        "ok": "208",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1793",
        "ok": "1793",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "456",
        "ok": "456",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "314",
        "ok": "314",
        "ko": "-"
    },
    "percentiles1": {
        "total": "379",
        "ok": "379",
        "ko": "-"
    },
    "percentiles2": {
        "total": "616",
        "ok": "616",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1148",
        "ok": "1148",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1505",
        "ok": "1505",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 185,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.885",
        "ok": "0.885",
        "ko": "-"
    }
}
    },"req_auth-buttons-js-47a35": {
        type: "REQUEST",
        name: "auth-buttons.js",
path: "auth-buttons.js",
pathFormatted: "req_auth-buttons-js-47a35",
stats: {
    "name": "auth-buttons.js",
    "numberOfRequests": {
        "total": "108",
        "ok": "108",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1789",
        "ok": "1789",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "509",
        "ok": "509",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "375",
        "ok": "375",
        "ko": "-"
    },
    "percentiles1": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles2": {
        "total": "706",
        "ok": "706",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1255",
        "ok": "1255",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1672",
        "ok": "1672",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 86,
    "percentage": 80
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.46",
        "ok": "0.46",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "168",
        "ok": "168",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1394",
        "ok": "1394",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "652",
        "ok": "652",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "percentiles1": {
        "total": "689",
        "ok": "689",
        "ko": "-"
    },
    "percentiles2": {
        "total": "829",
        "ok": "829",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1320",
        "ok": "1320",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 72,
    "percentage": 72
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 24,
    "percentage": 24
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1062",
        "ok": "1062",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "percentiles1": {
        "total": "212",
        "ok": "212",
        "ko": "-"
    },
    "percentiles2": {
        "total": "399",
        "ok": "399",
        "ko": "-"
    },
    "percentiles3": {
        "total": "711",
        "ok": "711",
        "ko": "-"
    },
    "percentiles4": {
        "total": "750",
        "ok": "750",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 99,
    "percentage": 99
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-2-redir-733ac": {
        type: "REQUEST",
        name: "request_2 Redirect 1",
path: "request_2 Redirect 1",
pathFormatted: "req_request-2-redir-733ac",
stats: {
    "name": "request_2 Redirect 1",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1682",
        "ok": "1682",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "619",
        "ok": "619",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "382",
        "ok": "382",
        "ko": "-"
    },
    "percentiles1": {
        "total": "674",
        "ok": "674",
        "ko": "-"
    },
    "percentiles2": {
        "total": "808",
        "ok": "808",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1369",
        "ok": "1369",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1664",
        "ok": "1664",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 71,
    "percentage": 71
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 21,
    "percentage": 21
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7927",
        "ok": "7927",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4420",
        "ok": "4420",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3342",
        "ok": "3342",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7281",
        "ok": "7281",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7519",
        "ok": "7519",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7837",
        "ok": "7837",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7926",
        "ok": "7926",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 23,
    "percentage": 23
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 17,
    "percentage": 17
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 60,
    "percentage": 60
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-3-redir-2cb6e": {
        type: "REQUEST",
        name: "request_3 Redirect 1",
path: "request_3 Redirect 1",
pathFormatted: "req_request-3-redir-2cb6e",
stats: {
    "name": "request_3 Redirect 1",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7339",
        "ok": "7339",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "673",
        "ok": "673",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1684",
        "ok": "1684",
        "ko": "-"
    },
    "percentiles1": {
        "total": "168",
        "ok": "168",
        "ko": "-"
    },
    "percentiles2": {
        "total": "291",
        "ok": "291",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7250",
        "ok": "7250",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7331",
        "ok": "7331",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 88,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-3-redir-9f15c": {
        type: "REQUEST",
        name: "request_3 Redirect 2",
path: "request_3 Redirect 2",
pathFormatted: "req_request-3-redir-9f15c",
stats: {
    "name": "request_3 Redirect 2",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7912",
        "ok": "7912",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1023",
        "ok": "1023",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1209",
        "ok": "1209",
        "ko": "-"
    },
    "percentiles1": {
        "total": "775",
        "ok": "775",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1046",
        "ok": "1046",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1642",
        "ok": "1642",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7815",
        "ok": "7815",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 54,
    "percentage": 54
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 37,
    "percentage": 37
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9,
    "percentage": 9
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-3-redir-08bb3": {
        type: "REQUEST",
        name: "request_3 Redirect 3",
path: "request_3 Redirect 3",
pathFormatted: "req_request-3-redir-08bb3",
stats: {
    "name": "request_3 Redirect 3",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1677",
        "ok": "1677",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "717",
        "ok": "717",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "percentiles1": {
        "total": "765",
        "ok": "765",
        "ko": "-"
    },
    "percentiles2": {
        "total": "816",
        "ok": "816",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1582",
        "ok": "1582",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 61,
    "percentage": 61
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 36,
    "percentage": 36
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "100",
        "ok": "40",
        "ko": "60"
    },
    "minResponseTime": {
        "total": "737",
        "ok": "737",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "38934",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "39430",
        "ok": "8575",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "26045",
        "ok": "10444",
        "ko": "1"
    },
    "percentiles1": {
        "total": "60000",
        "ok": "4803",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "60000",
        "ok": "7749",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "35951",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "38792",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 1
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 36,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "count": 60,
    "percentage": 60
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.17",
        "ko": "0.255"
    }
}
    },"req_mash-css-d5713": {
        type: "REQUEST",
        name: "mash.css",
path: "mash.css",
pathFormatted: "req_mash-css-d5713",
stats: {
    "name": "mash.css",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2974",
        "ok": "2974",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "447",
        "ok": "447",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "451",
        "ok": "451",
        "ko": "-"
    },
    "percentiles1": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "percentiles2": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "percentiles3": {
        "total": "754",
        "ok": "754",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2147",
        "ok": "2147",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 38,
    "percentage": 95
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.17",
        "ok": "0.17",
        "ko": "-"
    }
}
    },"req_mashlib-min-js-40849": {
        type: "REQUEST",
        name: "mashlib.min.js",
path: "mashlib.min.js",
pathFormatted: "req_mashlib-min-js-40849",
stats: {
    "name": "mashlib.min.js",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4843",
        "ok": "4843",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2774",
        "ok": "2774",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1262",
        "ok": "1262",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3240",
        "ok": "3240",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3547",
        "ok": "3547",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4559",
        "ok": "4559",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4752",
        "ok": "4752",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 5
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 13
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 33,
    "percentage": 83
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.17",
        "ok": "0.17",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "486",
        "ok": "486",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19912",
        "ok": "19912",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4543",
        "ok": "4543",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4473",
        "ok": "4473",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3418",
        "ok": "3418",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5091",
        "ok": "5091",
        "ko": "-"
    },
    "percentiles3": {
        "total": "11760",
        "ok": "11760",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19896",
        "ok": "19896",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 13
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 32,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.17",
        "ok": "0.17",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "494",
        "ok": "494",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8185",
        "ok": "8185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3165",
        "ok": "3165",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1850",
        "ok": "1850",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3299",
        "ok": "3299",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4544",
        "ok": "4544",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6862",
        "ok": "6862",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7708",
        "ok": "7708",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 33,
    "percentage": 83
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.17",
        "ok": "0.17",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "300",
        "ok": "300",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6964",
        "ok": "6964",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3012",
        "ok": "3012",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1625",
        "ok": "1625",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3398",
        "ok": "3398",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4445",
        "ok": "4445",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5024",
        "ok": "5024",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6516",
        "ok": "6516",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 32,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.17",
        "ok": "0.17",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "280",
        "ok": "280",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7009",
        "ok": "7009",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3142",
        "ok": "3142",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1824",
        "ok": "1824",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3385",
        "ok": "3385",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4595",
        "ok": "4595",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5999",
        "ok": "5999",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6948",
        "ok": "6948",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 13
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 32,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.17",
        "ok": "0.17",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1672",
        "ok": "1672",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "421",
        "ok": "421",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "265",
        "ok": "265",
        "ko": "-"
    },
    "percentiles1": {
        "total": "386",
        "ok": "386",
        "ko": "-"
    },
    "percentiles2": {
        "total": "458",
        "ok": "458",
        "ko": "-"
    },
    "percentiles3": {
        "total": "841",
        "ok": "841",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1383",
        "ok": "1383",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 94,
    "percentage": 94
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "235",
        "ok": "235",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21852",
        "ok": "21852",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6768",
        "ok": "6768",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5503",
        "ok": "5503",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6729",
        "ok": "6729",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11521",
        "ok": "11521",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14095",
        "ok": "14095",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21852",
        "ok": "21852",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 12,
    "percentage": 12
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 82,
    "percentage": 82
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2653",
        "ok": "2653",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1241",
        "ok": "1241",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "846",
        "ok": "846",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1629",
        "ok": "1629",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1947",
        "ok": "1947",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2502",
        "ok": "2502",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2517",
        "ok": "2517",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 42,
    "percentage": 42
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 52,
    "percentage": 52
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "462",
        "ok": "462",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28639",
        "ok": "28639",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14754",
        "ok": "14754",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11729",
        "ok": "11729",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22647",
        "ok": "22647",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25729",
        "ok": "25729",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27845",
        "ok": "27845",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28216",
        "ok": "28216",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 9
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 87,
    "percentage": 87
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "460",
        "ok": "460",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28208",
        "ok": "28208",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14739",
        "ok": "14739",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11706",
        "ok": "11706",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22652",
        "ok": "22652",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25725",
        "ok": "25725",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27844",
        "ok": "27844",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28201",
        "ok": "28201",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 9
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 87,
    "percentage": 87
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "298",
        "ok": "298",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27814",
        "ok": "27814",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13846",
        "ok": "13846",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11026",
        "ok": "11026",
        "ko": "-"
    },
    "percentiles1": {
        "total": "17421",
        "ok": "17421",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24546",
        "ok": "24546",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26934",
        "ok": "26934",
        "ko": "-"
    },
    "percentiles4": {
        "total": "27814",
        "ok": "27814",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 9
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 86,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "370",
        "ok": "370",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28213",
        "ok": "28213",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14826",
        "ok": "14826",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11635",
        "ok": "11635",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22650",
        "ok": "22650",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25727",
        "ok": "25727",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27842",
        "ok": "27842",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28198",
        "ok": "28198",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 9
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 87,
    "percentage": 87
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "509",
        "ok": "509",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27101",
        "ok": "27101",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15183",
        "ok": "15183",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12122",
        "ok": "12122",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25856",
        "ok": "25856",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26969",
        "ok": "26969",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27100",
        "ok": "27100",
        "ko": "-"
    },
    "percentiles4": {
        "total": "27100",
        "ok": "27100",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 7
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 86,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "258",
        "ok": "258",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10508",
        "ok": "10508",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "974",
        "ok": "974",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1430",
        "ok": "1430",
        "ko": "-"
    },
    "percentiles1": {
        "total": "566",
        "ok": "566",
        "ko": "-"
    },
    "percentiles2": {
        "total": "865",
        "ok": "865",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3353",
        "ok": "3353",
        "ko": "-"
    },
    "percentiles4": {
        "total": "8787",
        "ok": "8787",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 73,
    "percentage": 73
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 13,
    "percentage": 13
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.426",
        "ko": "-"
    }
}
    },"req_request-17-redi-ff1b4": {
        type: "REQUEST",
        name: "request_17 Redirect 1",
path: "request_17 Redirect 1",
pathFormatted: "req_request-17-redi-ff1b4",
stats: {
    "name": "request_17 Redirect 1",
    "numberOfRequests": {
        "total": "100",
        "ok": "71",
        "ko": "29"
    },
    "minResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "32550",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "20695",
        "ok": "4641",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "25831",
        "ok": "7145",
        "ko": "0"
    },
    "percentiles1": {
        "total": "3930",
        "ok": "1962",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "60000",
        "ok": "4272",
        "ko": "60000"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "16410",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "32355",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 22,
    "percentage": 22
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 47,
    "percentage": 47
},
    "group4": {
    "name": "failed",
    "count": 29,
    "percentage": 29
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.426",
        "ok": "0.302",
        "ko": "0.123"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
