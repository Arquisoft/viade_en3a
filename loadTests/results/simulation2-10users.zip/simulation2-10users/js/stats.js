var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "356",
        "ok": "355",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "31251",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "822",
        "ok": "656",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "3682",
        "ok": "1924",
        "ko": "0"
    },
    "percentiles1": {
        "total": "321",
        "ok": "320",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "598",
        "ok": "591",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "1720",
        "ok": "1718",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "5428",
        "ok": "3563",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 294,
    "percentage": 83
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 47,
    "percentage": 13
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5.086",
        "ok": "5.071",
        "ko": "0.014"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "percentiles1": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles2": {
        "total": "319",
        "ok": "319",
        "ko": "-"
    },
    "percentiles3": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "percentiles4": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "10",
        "ok": "9",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "31251",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "12006",
        "ok": "6674",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "18531",
        "ok": "9857",
        "ko": "0"
    },
    "percentiles1": {
        "total": "2239",
        "ok": "1239",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "13252",
        "ok": "7241",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "47063",
        "ok": "24853",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "57414",
        "ok": "29971",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 30
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.129",
        "ko": "0.014"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "29",
        "ok": "29",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "409",
        "ok": "409",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "143",
        "ok": "143",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "percentiles1": {
        "total": "151",
        "ok": "151",
        "ko": "-"
    },
    "percentiles2": {
        "total": "197",
        "ok": "197",
        "ko": "-"
    },
    "percentiles3": {
        "total": "350",
        "ok": "350",
        "ko": "-"
    },
    "percentiles4": {
        "total": "408",
        "ok": "408",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 29,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.414",
        "ok": "0.414",
        "ko": "-"
    }
}
    },"req_solid-css-8f91a": {
        type: "REQUEST",
        name: "solid.css",
path: "solid.css",
pathFormatted: "req_solid-css-8f91a",
stats: {
    "name": "solid.css",
    "numberOfRequests": {
        "total": "29",
        "ok": "29",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "559",
        "ok": "559",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "percentiles1": {
        "total": "197",
        "ok": "197",
        "ko": "-"
    },
    "percentiles2": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "percentiles3": {
        "total": "482",
        "ok": "482",
        "ko": "-"
    },
    "percentiles4": {
        "total": "545",
        "ok": "545",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 29,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.414",
        "ok": "0.414",
        "ko": "-"
    }
}
    },"req_solid-auth-clie-301ec": {
        type: "REQUEST",
        name: "solid-auth-client.bundle.js",
path: "solid-auth-client.bundle.js",
pathFormatted: "req_solid-auth-clie-301ec",
stats: {
    "name": "solid-auth-client.bundle.js",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "47",
        "ok": "47",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1058",
        "ok": "1058",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "388",
        "ok": "388",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "206",
        "ok": "206",
        "ko": "-"
    },
    "percentiles1": {
        "total": "350",
        "ok": "350",
        "ko": "-"
    },
    "percentiles2": {
        "total": "391",
        "ok": "391",
        "ko": "-"
    },
    "percentiles3": {
        "total": "706",
        "ok": "706",
        "ko": "-"
    },
    "percentiles4": {
        "total": "988",
        "ok": "988",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 18,
    "percentage": 95
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.271",
        "ok": "0.271",
        "ko": "-"
    }
}
    },"req_auth-buttons-js-47a35": {
        type: "REQUEST",
        name: "auth-buttons.js",
path: "auth-buttons.js",
pathFormatted: "req_auth-buttons-js-47a35",
stats: {
    "name": "auth-buttons.js",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "163",
        "ok": "163",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "626",
        "ok": "626",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "121",
        "ok": "121",
        "ko": "-"
    },
    "percentiles1": {
        "total": "276",
        "ok": "276",
        "ko": "-"
    },
    "percentiles2": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles3": {
        "total": "468",
        "ok": "468",
        "ko": "-"
    },
    "percentiles4": {
        "total": "595",
        "ok": "595",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.271",
        "ok": "0.271",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "146",
        "ok": "146",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "640",
        "ok": "640",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "142",
        "ok": "142",
        "ko": "-"
    },
    "percentiles1": {
        "total": "178",
        "ok": "178",
        "ko": "-"
    },
    "percentiles2": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "percentiles3": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles4": {
        "total": "609",
        "ok": "609",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "101",
        "ok": "101",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "percentiles1": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "percentiles2": {
        "total": "76",
        "ok": "76",
        "ko": "-"
    },
    "percentiles3": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "percentiles4": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-2-redir-733ac": {
        type: "REQUEST",
        name: "request_2 Redirect 1",
path: "request_2 Redirect 1",
pathFormatted: "req_request-2-redir-733ac",
stats: {
    "name": "request_2 Redirect 1",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "58",
        "ok": "58",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "587",
        "ok": "587",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "159",
        "ok": "159",
        "ko": "-"
    },
    "percentiles1": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "percentiles2": {
        "total": "195",
        "ok": "195",
        "ko": "-"
    },
    "percentiles3": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "percentiles4": {
        "total": "557",
        "ok": "557",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "223",
        "ok": "223",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "444",
        "ok": "444",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "percentiles1": {
        "total": "328",
        "ok": "328",
        "ko": "-"
    },
    "percentiles2": {
        "total": "395",
        "ok": "395",
        "ko": "-"
    },
    "percentiles3": {
        "total": "431",
        "ok": "431",
        "ko": "-"
    },
    "percentiles4": {
        "total": "441",
        "ok": "441",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-3-redir-2cb6e": {
        type: "REQUEST",
        name: "request_3 Redirect 1",
path: "request_3 Redirect 1",
pathFormatted: "req_request-3-redir-2cb6e",
stats: {
    "name": "request_3 Redirect 1",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "91",
        "ok": "91",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "314",
        "ok": "314",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "88",
        "ok": "88",
        "ko": "-"
    },
    "percentiles1": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "percentiles2": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "percentiles3": {
        "total": "314",
        "ok": "314",
        "ko": "-"
    },
    "percentiles4": {
        "total": "314",
        "ok": "314",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-3-redir-9f15c": {
        type: "REQUEST",
        name: "request_3 Redirect 2",
path: "request_3 Redirect 2",
pathFormatted: "req_request-3-redir-9f15c",
stats: {
    "name": "request_3 Redirect 2",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "525",
        "ok": "525",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "154",
        "ok": "154",
        "ko": "-"
    },
    "percentiles1": {
        "total": "142",
        "ok": "142",
        "ko": "-"
    },
    "percentiles2": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles3": {
        "total": "479",
        "ok": "479",
        "ko": "-"
    },
    "percentiles4": {
        "total": "516",
        "ok": "516",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-3-redir-08bb3": {
        type: "REQUEST",
        name: "request_3 Redirect 3",
path: "request_3 Redirect 3",
pathFormatted: "req_request-3-redir-08bb3",
stats: {
    "name": "request_3 Redirect 3",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "149",
        "ok": "149",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "490",
        "ok": "490",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "114",
        "ok": "114",
        "ko": "-"
    },
    "percentiles1": {
        "total": "208",
        "ok": "208",
        "ko": "-"
    },
    "percentiles2": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "percentiles3": {
        "total": "477",
        "ok": "477",
        "ko": "-"
    },
    "percentiles4": {
        "total": "487",
        "ok": "487",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "273",
        "ok": "273",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3944",
        "ok": "3944",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "969",
        "ok": "969",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1025",
        "ok": "1025",
        "ko": "-"
    },
    "percentiles1": {
        "total": "740",
        "ok": "740",
        "ko": "-"
    },
    "percentiles2": {
        "total": "935",
        "ok": "935",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2633",
        "ok": "2633",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3682",
        "ok": "3682",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6,
    "percentage": 60
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 30
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_mash-css-d5713": {
        type: "REQUEST",
        name: "mash.css",
path: "mash.css",
pathFormatted: "req_mash-css-d5713",
stats: {
    "name": "mash.css",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "78",
        "ok": "78",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "206",
        "ok": "206",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "percentiles1": {
        "total": "96",
        "ok": "96",
        "ko": "-"
    },
    "percentiles2": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "percentiles3": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "percentiles4": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_mashlib-min-js-40849": {
        type: "REQUEST",
        name: "mashlib.min.js",
path: "mashlib.min.js",
pathFormatted: "req_mashlib-min-js-40849",
stats: {
    "name": "mashlib.min.js",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "532",
        "ok": "532",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1712",
        "ok": "1712",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1165",
        "ok": "1165",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "457",
        "ok": "457",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1139",
        "ok": "1139",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1648",
        "ok": "1648",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1708",
        "ok": "1708",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1711",
        "ok": "1711",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 40
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "418",
        "ok": "418",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2790",
        "ok": "2790",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1303",
        "ok": "1303",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "833",
        "ok": "833",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1057",
        "ok": "1057",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1705",
        "ok": "1705",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2711",
        "ok": "2711",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2774",
        "ok": "2774",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 50
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2808",
        "ok": "2808",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1136",
        "ok": "1136",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "740",
        "ok": "740",
        "ko": "-"
    },
    "percentiles1": {
        "total": "916",
        "ok": "916",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1601",
        "ok": "1601",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2347",
        "ok": "2347",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2716",
        "ok": "2716",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 50
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2838",
        "ok": "2838",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1175",
        "ok": "1175",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "731",
        "ok": "731",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1024",
        "ok": "1024",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1625",
        "ok": "1625",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2354",
        "ok": "2354",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2741",
        "ok": "2741",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 40
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "511",
        "ok": "511",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1909",
        "ok": "1909",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1115",
        "ok": "1115",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "525",
        "ok": "525",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1024",
        "ok": "1024",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1659",
        "ok": "1659",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1831",
        "ok": "1831",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1893",
        "ok": "1893",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 40
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "47",
        "ok": "47",
        "ko": "-"
    },
    "percentiles1": {
        "total": "50",
        "ok": "50",
        "ko": "-"
    },
    "percentiles2": {
        "total": "99",
        "ok": "99",
        "ko": "-"
    },
    "percentiles3": {
        "total": "158",
        "ok": "158",
        "ko": "-"
    },
    "percentiles4": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "114",
        "ok": "114",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "percentiles1": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles2": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "percentiles3": {
        "total": "225",
        "ok": "225",
        "ko": "-"
    },
    "percentiles4": {
        "total": "236",
        "ok": "236",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1567",
        "ok": "1567",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "716",
        "ok": "716",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "401",
        "ok": "401",
        "ko": "-"
    },
    "percentiles1": {
        "total": "465",
        "ok": "465",
        "ko": "-"
    },
    "percentiles2": {
        "total": "904",
        "ok": "904",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1450",
        "ok": "1450",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1544",
        "ok": "1544",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 70
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 20
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "456",
        "ok": "456",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1722",
        "ok": "1722",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "891",
        "ok": "891",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "484",
        "ok": "484",
        "ko": "-"
    },
    "percentiles1": {
        "total": "636",
        "ok": "636",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1254",
        "ok": "1254",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1708",
        "ok": "1708",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1719",
        "ok": "1719",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 70
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "456",
        "ok": "456",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1717",
        "ok": "1717",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "891",
        "ok": "891",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles1": {
        "total": "637",
        "ok": "637",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1251",
        "ok": "1251",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1708",
        "ok": "1708",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1715",
        "ok": "1715",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 70
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "351",
        "ok": "351",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1689",
        "ok": "1689",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "787",
        "ok": "787",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "504",
        "ok": "504",
        "ko": "-"
    },
    "percentiles1": {
        "total": "509",
        "ok": "509",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1205",
        "ok": "1205",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1624",
        "ok": "1624",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1676",
        "ok": "1676",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 70
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "349",
        "ok": "349",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1721",
        "ok": "1721",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "877",
        "ok": "877",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "495",
        "ok": "495",
        "ko": "-"
    },
    "percentiles1": {
        "total": "636",
        "ok": "636",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1248",
        "ok": "1248",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1708",
        "ok": "1708",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1718",
        "ok": "1718",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 70
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "474",
        "ok": "474",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1758",
        "ok": "1758",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "945",
        "ok": "945",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "464",
        "ok": "464",
        "ko": "-"
    },
    "percentiles1": {
        "total": "697",
        "ok": "697",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1241",
        "ok": "1241",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1749",
        "ok": "1749",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1756",
        "ok": "1756",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6,
    "percentage": 60
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "123",
        "ok": "123",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "849",
        "ok": "849",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "378",
        "ok": "378",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "percentiles1": {
        "total": "352",
        "ok": "352",
        "ko": "-"
    },
    "percentiles2": {
        "total": "444",
        "ok": "444",
        "ko": "-"
    },
    "percentiles3": {
        "total": "692",
        "ok": "692",
        "ko": "-"
    },
    "percentiles4": {
        "total": "818",
        "ok": "818",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 90
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_request-17-redi-ff1b4": {
        type: "REQUEST",
        name: "request_17 Redirect 1",
path: "request_17 Redirect 1",
pathFormatted: "req_request-17-redi-ff1b4",
stats: {
    "name": "request_17 Redirect 1",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "110",
        "ok": "110",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1579",
        "ok": "1579",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "506",
        "ok": "506",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "527",
        "ok": "527",
        "ko": "-"
    },
    "percentiles1": {
        "total": "244",
        "ok": "244",
        "ko": "-"
    },
    "percentiles2": {
        "total": "565",
        "ok": "565",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1521",
        "ok": "1521",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1567",
        "ok": "1567",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8,
    "percentage": 80
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 20
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
