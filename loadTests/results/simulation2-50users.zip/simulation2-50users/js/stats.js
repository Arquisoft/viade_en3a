var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "1668",
        "ok": "1641",
        "ko": "27"
    },
    "minResponseTime": {
        "total": "36",
        "ok": "36",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "34918",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "2402",
        "ok": "1454",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "7835",
        "ok": "2630",
        "ko": "1"
    },
    "percentiles1": {
        "total": "523",
        "ok": "503",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "1949",
        "ok": "1871",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "5034",
        "ok": "4754",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "8219",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 979,
    "percentage": 59
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 143,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 519,
    "percentage": 31
},
    "group4": {
    "name": "failed",
    "count": 27,
    "percentage": 2
},
    "meanNumberOfRequestsPerSecond": {
        "total": "12.541",
        "ok": "12.338",
        "ko": "0.203"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "357",
        "ok": "357",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "485",
        "ok": "485",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "426",
        "ok": "426",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "percentiles1": {
        "total": "432",
        "ok": "432",
        "ko": "-"
    },
    "percentiles2": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "percentiles3": {
        "total": "477",
        "ok": "477",
        "ko": "-"
    },
    "percentiles4": {
        "total": "484",
        "ok": "484",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 50,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "35",
        "ko": "15"
    },
    "minResponseTime": {
        "total": "137",
        "ok": "137",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "32479",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "20815",
        "ok": "4021",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "26113",
        "ok": "5835",
        "ko": "0"
    },
    "percentiles1": {
        "total": "3958",
        "ok": "1963",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "60000",
        "ok": "4088",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "10711",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "27048",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 28,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "count": 15,
    "percentage": 30
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.263",
        "ko": "0.113"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "135",
        "ok": "135",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "975",
        "ok": "975",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "227",
        "ok": "227",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "percentiles1": {
        "total": "164",
        "ok": "164",
        "ko": "-"
    },
    "percentiles2": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "percentiles3": {
        "total": "826",
        "ok": "826",
        "ko": "-"
    },
    "percentiles4": {
        "total": "921",
        "ok": "921",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 126,
    "percentage": 93
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 9,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.015",
        "ok": "1.015",
        "ko": "-"
    }
}
    },"req_solid-css-8f91a": {
        type: "REQUEST",
        name: "solid.css",
path: "solid.css",
pathFormatted: "req_solid-css-8f91a",
stats: {
    "name": "solid.css",
    "numberOfRequests": {
        "total": "135",
        "ok": "135",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1396",
        "ok": "1396",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "percentiles1": {
        "total": "238",
        "ok": "238",
        "ko": "-"
    },
    "percentiles2": {
        "total": "439",
        "ok": "439",
        "ko": "-"
    },
    "percentiles3": {
        "total": "928",
        "ok": "928",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1280",
        "ok": "1280",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 120,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.015",
        "ok": "1.015",
        "ko": "-"
    }
}
    },"req_solid-auth-clie-301ec": {
        type: "REQUEST",
        name: "solid-auth-client.bundle.js",
path: "solid-auth-client.bundle.js",
pathFormatted: "req_solid-auth-clie-301ec",
stats: {
    "name": "solid-auth-client.bundle.js",
    "numberOfRequests": {
        "total": "85",
        "ok": "85",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "120",
        "ok": "120",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1648",
        "ok": "1648",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "568",
        "ok": "568",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "344",
        "ok": "344",
        "ko": "-"
    },
    "percentiles1": {
        "total": "454",
        "ok": "454",
        "ko": "-"
    },
    "percentiles2": {
        "total": "788",
        "ok": "788",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1164",
        "ok": "1164",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1582",
        "ok": "1582",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 65,
    "percentage": 76
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 17,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.639",
        "ok": "0.639",
        "ko": "-"
    }
}
    },"req_auth-buttons-js-47a35": {
        type: "REQUEST",
        name: "auth-buttons.js",
path: "auth-buttons.js",
pathFormatted: "req_auth-buttons-js-47a35",
stats: {
    "name": "auth-buttons.js",
    "numberOfRequests": {
        "total": "85",
        "ok": "85",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "118",
        "ok": "118",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1401",
        "ok": "1401",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "447",
        "ok": "447",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles1": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "percentiles2": {
        "total": "618",
        "ok": "618",
        "ko": "-"
    },
    "percentiles3": {
        "total": "980",
        "ok": "980",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1333",
        "ok": "1333",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 72,
    "percentage": 85
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 13
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.639",
        "ok": "0.639",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2011",
        "ok": "2011",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "470",
        "ok": "470",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "percentiles1": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "percentiles2": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1736",
        "ok": "1736",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1994",
        "ok": "1994",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 43,
    "percentage": 86
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 7,
    "percentage": 14
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1404",
        "ok": "1404",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "368",
        "ok": "368",
        "ko": "-"
    },
    "percentiles1": {
        "total": "72",
        "ok": "72",
        "ko": "-"
    },
    "percentiles2": {
        "total": "265",
        "ok": "265",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1256",
        "ok": "1256",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1347",
        "ok": "1347",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 45,
    "percentage": 90
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-2-redir-733ac": {
        type: "REQUEST",
        name: "request_2 Redirect 1",
path: "request_2 Redirect 1",
pathFormatted: "req_request-2-redir-733ac",
stats: {
    "name": "request_2 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1563",
        "ok": "1563",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "361",
        "ok": "361",
        "ko": "-"
    },
    "percentiles1": {
        "total": "208",
        "ok": "208",
        "ko": "-"
    },
    "percentiles2": {
        "total": "398",
        "ok": "398",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1188",
        "ok": "1188",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1547",
        "ok": "1547",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 45,
    "percentage": 90
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2018",
        "ok": "2018",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1193",
        "ok": "1193",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "543",
        "ok": "543",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1295",
        "ok": "1295",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1534",
        "ok": "1534",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1936",
        "ok": "1936",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2000",
        "ok": "2000",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 13,
    "percentage": 26
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 27,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-3-redir-2cb6e": {
        type: "REQUEST",
        name: "request_3 Redirect 1",
path: "request_3 Redirect 1",
pathFormatted: "req_request-3-redir-2cb6e",
stats: {
    "name": "request_3 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "86",
        "ok": "86",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1206",
        "ok": "1206",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "442",
        "ok": "442",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "424",
        "ok": "424",
        "ko": "-"
    },
    "percentiles1": {
        "total": "156",
        "ok": "156",
        "ko": "-"
    },
    "percentiles2": {
        "total": "945",
        "ok": "945",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1199",
        "ok": "1199",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1205",
        "ok": "1205",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 35,
    "percentage": 70
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 26
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-3-redir-9f15c": {
        type: "REQUEST",
        name: "request_3 Redirect 2",
path: "request_3 Redirect 2",
pathFormatted: "req_request-3-redir-9f15c",
stats: {
    "name": "request_3 Redirect 2",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1296",
        "ok": "1296",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "404",
        "ok": "404",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "278",
        "ok": "278",
        "ko": "-"
    },
    "percentiles1": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles2": {
        "total": "433",
        "ok": "433",
        "ko": "-"
    },
    "percentiles3": {
        "total": "951",
        "ok": "951",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1244",
        "ok": "1244",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 44,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-3-redir-08bb3": {
        type: "REQUEST",
        name: "request_3 Redirect 3",
path: "request_3 Redirect 3",
pathFormatted: "req_request-3-redir-08bb3",
stats: {
    "name": "request_3 Redirect 3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1413",
        "ok": "1413",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "469",
        "ok": "469",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "percentiles1": {
        "total": "377",
        "ok": "377",
        "ko": "-"
    },
    "percentiles2": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles3": {
        "total": "928",
        "ok": "928",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1370",
        "ok": "1370",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 44,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "50",
        "ok": "38",
        "ko": "12"
    },
    "minResponseTime": {
        "total": "278",
        "ok": "278",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "34918",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "20731",
        "ok": "8330",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "23811",
        "ok": "10257",
        "ko": "1"
    },
    "percentiles1": {
        "total": "5983",
        "ok": "3572",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "34770",
        "ok": "8190",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "34246",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "34699",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 10
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 32,
    "percentage": 64
},
    "group4": {
    "name": "failed",
    "count": 12,
    "percentage": 24
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.286",
        "ko": "0.09"
    }
}
    },"req_mash-css-d5713": {
        type: "REQUEST",
        name: "mash.css",
path: "mash.css",
pathFormatted: "req_mash-css-d5713",
stats: {
    "name": "mash.css",
    "numberOfRequests": {
        "total": "38",
        "ok": "38",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "83",
        "ok": "83",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1240",
        "ok": "1240",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "266",
        "ok": "266",
        "ko": "-"
    },
    "percentiles1": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "percentiles2": {
        "total": "535",
        "ok": "535",
        "ko": "-"
    },
    "percentiles3": {
        "total": "812",
        "ok": "812",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1097",
        "ok": "1097",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 35,
    "percentage": 92
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.286",
        "ok": "0.286",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "38",
        "ok": "38",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "319",
        "ok": "319",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18719",
        "ok": "18719",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3741",
        "ok": "3741",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3434",
        "ok": "3434",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3374",
        "ok": "3374",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4666",
        "ok": "4666",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8491",
        "ok": "8491",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15988",
        "ok": "15988",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 30,
    "percentage": 79
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.286",
        "ok": "0.286",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "38",
        "ok": "38",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "281",
        "ok": "281",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6591",
        "ok": "6591",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2831",
        "ok": "2831",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1668",
        "ok": "1668",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3046",
        "ok": "3046",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3977",
        "ok": "3977",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5647",
        "ok": "5647",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6293",
        "ok": "6293",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 30,
    "percentage": 79
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.286",
        "ok": "0.286",
        "ko": "-"
    }
}
    },"req_mashlib-min-js-40849": {
        type: "REQUEST",
        name: "mashlib.min.js",
path: "mashlib.min.js",
pathFormatted: "req_mashlib-min-js-40849",
stats: {
    "name": "mashlib.min.js",
    "numberOfRequests": {
        "total": "38",
        "ok": "38",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "578",
        "ok": "578",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5862",
        "ok": "5862",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2804",
        "ok": "2804",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1508",
        "ok": "1508",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3038",
        "ok": "3038",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5413",
        "ok": "5413",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5697",
        "ok": "5697",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 29,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.286",
        "ok": "0.286",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "38",
        "ok": "38",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6418",
        "ok": "6418",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2890",
        "ok": "2890",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1665",
        "ok": "1665",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3117",
        "ok": "3117",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4006",
        "ok": "4006",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5584",
        "ok": "5584",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6160",
        "ok": "6160",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 30,
    "percentage": 79
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.286",
        "ok": "0.286",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "38",
        "ok": "38",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "301",
        "ok": "301",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6589",
        "ok": "6589",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2885",
        "ok": "2885",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1691",
        "ok": "1691",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3020",
        "ok": "3020",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4044",
        "ok": "4044",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5649",
        "ok": "5649",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6290",
        "ok": "6290",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 30,
    "percentage": 79
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.286",
        "ok": "0.286",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2816",
        "ok": "2816",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "477",
        "ok": "477",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "percentiles1": {
        "total": "288",
        "ok": "288",
        "ko": "-"
    },
    "percentiles2": {
        "total": "660",
        "ok": "660",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1522",
        "ok": "1522",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2447",
        "ok": "2447",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 43,
    "percentage": 86
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2161",
        "ok": "2161",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "468",
        "ok": "468",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "429",
        "ok": "429",
        "ko": "-"
    },
    "percentiles1": {
        "total": "388",
        "ok": "388",
        "ko": "-"
    },
    "percentiles2": {
        "total": "593",
        "ok": "593",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1369",
        "ok": "1369",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1782",
        "ok": "1782",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 41,
    "percentage": 82
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "456",
        "ok": "456",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5323",
        "ok": "5323",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2812",
        "ok": "2812",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1621",
        "ok": "1621",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3065",
        "ok": "3065",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4323",
        "ok": "4323",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4837",
        "ok": "4837",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5283",
        "ok": "5283",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 36,
    "percentage": 72
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "463",
        "ok": "463",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5327",
        "ok": "5327",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2797",
        "ok": "2797",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1590",
        "ok": "1590",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3064",
        "ok": "3064",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4251",
        "ok": "4251",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4830",
        "ok": "4830",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5283",
        "ok": "5283",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 37,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "321",
        "ok": "321",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5313",
        "ok": "5313",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2684",
        "ok": "2684",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1535",
        "ok": "1535",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2960",
        "ok": "2960",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4105",
        "ok": "4105",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4788",
        "ok": "4788",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5175",
        "ok": "5175",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 37,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "359",
        "ok": "359",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5310",
        "ok": "5310",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2939",
        "ok": "2939",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1674",
        "ok": "1674",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3580",
        "ok": "3580",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4455",
        "ok": "4455",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4874",
        "ok": "4874",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5273",
        "ok": "5273",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 36,
    "percentage": 72
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4356",
        "ok": "4356",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2067",
        "ok": "2067",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1297",
        "ok": "1297",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1872",
        "ok": "1872",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3290",
        "ok": "3290",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4115",
        "ok": "4115",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4282",
        "ok": "4282",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 13,
    "percentage": 26
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 34,
    "percentage": 68
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "495",
        "ok": "495",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5101",
        "ok": "5101",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2754",
        "ok": "2754",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1554",
        "ok": "1554",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3120",
        "ok": "3120",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4086",
        "ok": "4086",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4885",
        "ok": "4885",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4996",
        "ok": "4996",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 20
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 38,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "137",
        "ok": "137",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1829",
        "ok": "1829",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "percentiles1": {
        "total": "629",
        "ok": "629",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1113",
        "ok": "1113",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1505",
        "ok": "1505",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1804",
        "ok": "1804",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 28,
    "percentage": 56
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 28
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    },"req_request-17-redi-ff1b4": {
        type: "REQUEST",
        name: "request_17 Redirect 1",
path: "request_17 Redirect 1",
pathFormatted: "req_request-17-redi-ff1b4",
stats: {
    "name": "request_17 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16937",
        "ok": "16937",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1813",
        "ok": "1813",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2718",
        "ok": "2718",
        "ko": "-"
    },
    "percentiles1": {
        "total": "949",
        "ok": "949",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2360",
        "ok": "2360",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4516",
        "ok": "4516",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13017",
        "ok": "13017",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 21,
    "percentage": 42
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 22,
    "percentage": 44
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.376",
        "ok": "0.376",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
