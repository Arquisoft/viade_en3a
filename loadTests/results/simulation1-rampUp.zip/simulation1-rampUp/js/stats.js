var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "1041",
        "ok": "1038",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "251"
    },
    "maxResponseTime": {
        "total": "6773",
        "ok": "6773",
        "ko": "548"
    },
    "meanResponseTime": {
        "total": "597",
        "ok": "597",
        "ko": "410"
    },
    "standardDeviation": {
        "total": "674",
        "ok": "675",
        "ko": "122"
    },
    "percentiles1": {
        "total": "387",
        "ok": "387",
        "ko": "430"
    },
    "percentiles2": {
        "total": "773",
        "ok": "774",
        "ko": "489"
    },
    "percentiles3": {
        "total": "1802",
        "ok": "1804",
        "ko": "536"
    },
    "percentiles4": {
        "total": "3230",
        "ok": "3231",
        "ko": "546"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 798,
    "percentage": 77
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 135,
    "percentage": 13
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 105,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.88",
        "ok": "13.84",
        "ko": "0.04"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1079",
        "ok": "1079",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "562",
        "ok": "562",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "percentiles1": {
        "total": "493",
        "ok": "493",
        "ko": "-"
    },
    "percentiles2": {
        "total": "752",
        "ok": "752",
        "ko": "-"
    },
    "percentiles3": {
        "total": "955",
        "ok": "955",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1046",
        "ok": "1046",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 39,
    "percentage": 78
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 22
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2322",
        "ok": "2322",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "720",
        "ok": "720",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "650",
        "ok": "650",
        "ko": "-"
    },
    "percentiles1": {
        "total": "396",
        "ok": "396",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1177",
        "ok": "1177",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2043",
        "ok": "2043",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2263",
        "ok": "2263",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 32,
    "percentage": 64
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 12,
    "percentage": 24
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "97",
        "ok": "97",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "916",
        "ok": "916",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "222",
        "ok": "222",
        "ko": "-"
    },
    "percentiles1": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "percentiles2": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "percentiles3": {
        "total": "783",
        "ok": "783",
        "ko": "-"
    },
    "percentiles4": {
        "total": "900",
        "ok": "900",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 95,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.293",
        "ok": "1.293",
        "ko": "-"
    }
}
    },"req_solid-auth-clie-301ec": {
        type: "REQUEST",
        name: "solid-auth-client.bundle.js",
path: "solid-auth-client.bundle.js",
pathFormatted: "req_solid-auth-clie-301ec",
stats: {
    "name": "solid-auth-client.bundle.js",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1882",
        "ok": "1882",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "744",
        "ok": "744",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "387",
        "ok": "387",
        "ko": "-"
    },
    "percentiles1": {
        "total": "639",
        "ok": "639",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1033",
        "ok": "1033",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1426",
        "ok": "1426",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1741",
        "ok": "1741",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 33,
    "percentage": 66
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 9,
    "percentage": 18
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_solid-css-8f91a": {
        type: "REQUEST",
        name: "solid.css",
path: "solid.css",
pathFormatted: "req_solid-css-8f91a",
stats: {
    "name": "solid.css",
    "numberOfRequests": {
        "total": "97",
        "ok": "97",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1353",
        "ok": "1353",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "338",
        "ok": "338",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "291",
        "ok": "291",
        "ko": "-"
    },
    "percentiles1": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "percentiles2": {
        "total": "491",
        "ok": "491",
        "ko": "-"
    },
    "percentiles3": {
        "total": "899",
        "ok": "899",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1046",
        "ok": "1046",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 86,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.293",
        "ok": "1.293",
        "ko": "-"
    }
}
    },"req_auth-buttons-js-47a35": {
        type: "REQUEST",
        name: "auth-buttons.js",
path: "auth-buttons.js",
pathFormatted: "req_auth-buttons-js-47a35",
stats: {
    "name": "auth-buttons.js",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1360",
        "ok": "1360",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "508",
        "ok": "508",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles1": {
        "total": "406",
        "ok": "406",
        "ko": "-"
    },
    "percentiles2": {
        "total": "766",
        "ok": "766",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1055",
        "ok": "1055",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1256",
        "ok": "1256",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 39,
    "percentage": 78
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1129",
        "ok": "1129",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "420",
        "ok": "420",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "percentiles1": {
        "total": "313",
        "ok": "313",
        "ko": "-"
    },
    "percentiles2": {
        "total": "586",
        "ok": "586",
        "ko": "-"
    },
    "percentiles3": {
        "total": "940",
        "ok": "940",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1114",
        "ok": "1114",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 46,
    "percentage": 92
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "50",
        "ok": "47",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "251"
    },
    "maxResponseTime": {
        "total": "919",
        "ok": "919",
        "ko": "548"
    },
    "meanResponseTime": {
        "total": "226",
        "ok": "214",
        "ko": "410"
    },
    "standardDeviation": {
        "total": "202",
        "ok": "201",
        "ko": "122"
    },
    "percentiles1": {
        "total": "141",
        "ok": "136",
        "ko": "430"
    },
    "percentiles2": {
        "total": "291",
        "ok": "281",
        "ko": "489"
    },
    "percentiles3": {
        "total": "602",
        "ok": "610",
        "ko": "536"
    },
    "percentiles4": {
        "total": "851",
        "ok": "855",
        "ko": "546"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 46,
    "percentage": 92
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 3,
    "percentage": 6
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.627",
        "ko": "0.04"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1053",
        "ok": "1053",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "438",
        "ok": "438",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "percentiles1": {
        "total": "347",
        "ok": "347",
        "ko": "-"
    },
    "percentiles2": {
        "total": "458",
        "ok": "458",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1023",
        "ok": "1023",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1052",
        "ok": "1052",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 43,
    "percentage": 86
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-3-redir-2cb6e": {
        type: "REQUEST",
        name: "request_3 Redirect 1",
path: "request_3 Redirect 1",
pathFormatted: "req_request-3-redir-2cb6e",
stats: {
    "name": "request_3 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "551",
        "ok": "551",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "169",
        "ok": "169",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "94",
        "ok": "94",
        "ko": "-"
    },
    "percentiles1": {
        "total": "139",
        "ok": "139",
        "ko": "-"
    },
    "percentiles2": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "percentiles3": {
        "total": "347",
        "ok": "347",
        "ko": "-"
    },
    "percentiles4": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 50,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-3-redir-9f15c": {
        type: "REQUEST",
        name: "request_3 Redirect 2",
path: "request_3 Redirect 2",
pathFormatted: "req_request-3-redir-9f15c",
stats: {
    "name": "request_3 Redirect 2",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "92",
        "ok": "92",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1041",
        "ok": "1041",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "326",
        "ok": "326",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "percentiles1": {
        "total": "223",
        "ok": "223",
        "ko": "-"
    },
    "percentiles2": {
        "total": "464",
        "ok": "464",
        "ko": "-"
    },
    "percentiles3": {
        "total": "807",
        "ok": "807",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1034",
        "ok": "1034",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 47,
    "percentage": 94
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-3-redir-08bb3": {
        type: "REQUEST",
        name: "request_3 Redirect 3",
path: "request_3 Redirect 3",
pathFormatted: "req_request-3-redir-08bb3",
stats: {
    "name": "request_3 Redirect 3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1351",
        "ok": "1351",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "418",
        "ok": "418",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "percentiles1": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles2": {
        "total": "457",
        "ok": "457",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1094",
        "ok": "1094",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1325",
        "ok": "1325",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 44,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-2-redir-733ac": {
        type: "REQUEST",
        name: "request_2 Redirect 1",
path: "request_2 Redirect 1",
pathFormatted: "req_request-2-redir-733ac",
stats: {
    "name": "request_2 Redirect 1",
    "numberOfRequests": {
        "total": "47",
        "ok": "47",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1310",
        "ok": "1310",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "321",
        "ok": "321",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "288",
        "ok": "288",
        "ko": "-"
    },
    "percentiles1": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "percentiles2": {
        "total": "448",
        "ok": "448",
        "ko": "-"
    },
    "percentiles3": {
        "total": "937",
        "ok": "937",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1166",
        "ok": "1166",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 42,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.627",
        "ok": "0.627",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "312",
        "ok": "312",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5810",
        "ok": "5810",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1465",
        "ok": "1465",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1362",
        "ok": "1362",
        "ko": "-"
    },
    "percentiles1": {
        "total": "912",
        "ok": "912",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1413",
        "ok": "1413",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4674",
        "ok": "4674",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5439",
        "ok": "5439",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 18,
    "percentage": 36
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 26
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 19,
    "percentage": 38
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "164",
        "ok": "164",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3056",
        "ok": "3056",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "764",
        "ok": "764",
        "ko": "-"
    },
    "percentiles1": {
        "total": "604",
        "ok": "604",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1030",
        "ok": "1030",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2634",
        "ok": "2634",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2901",
        "ok": "2901",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 32,
    "percentage": 64
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 11,
    "percentage": 22
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "336",
        "ok": "336",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3577",
        "ok": "3577",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1172",
        "ok": "1172",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "831",
        "ok": "831",
        "ko": "-"
    },
    "percentiles1": {
        "total": "889",
        "ok": "889",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1406",
        "ok": "1406",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3058",
        "ok": "3058",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3415",
        "ok": "3415",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 18,
    "percentage": 36
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 32
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 16,
    "percentage": 32
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "191",
        "ok": "191",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6773",
        "ok": "6773",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1128",
        "ok": "1128",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1236",
        "ok": "1236",
        "ko": "-"
    },
    "percentiles1": {
        "total": "721",
        "ok": "721",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1378",
        "ok": "1378",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3422",
        "ok": "3422",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5903",
        "ok": "5903",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 29,
    "percentage": 58
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 17,
    "percentage": 34
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "251",
        "ok": "251",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3455",
        "ok": "3455",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "964",
        "ok": "964",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "745",
        "ok": "745",
        "ko": "-"
    },
    "percentiles1": {
        "total": "757",
        "ok": "757",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1100",
        "ok": "1100",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2409",
        "ok": "2409",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3230",
        "ok": "3230",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 27,
    "percentage": 54
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 12,
    "percentage": 24
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 11,
    "percentage": 22
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "244",
        "ok": "244",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3064",
        "ok": "3064",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "805",
        "ok": "805",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "605",
        "ok": "605",
        "ko": "-"
    },
    "percentiles1": {
        "total": "618",
        "ok": "618",
        "ko": "-"
    },
    "percentiles2": {
        "total": "969",
        "ok": "969",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2189",
        "ok": "2189",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2853",
        "ok": "2853",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 32,
    "percentage": 64
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 12,
    "percentage": 24
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 12
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.667",
        "ok": "0.667",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
