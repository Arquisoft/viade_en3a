var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "996",
        "ok": "973",
        "ko": "23"
    },
    "minResponseTime": {
        "total": "37",
        "ok": "37",
        "ko": "462"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "35383",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "2316",
        "ok": "1075",
        "ko": "54824"
    },
    "standardDeviation": {
        "total": "8975",
        "ok": "3016",
        "ko": "16776"
    },
    "percentiles1": {
        "total": "376",
        "ok": "369",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "963",
        "ok": "877",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "4622",
        "ok": "3229",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "16368",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 710,
    "percentage": 71
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 72,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 191,
    "percentage": 19
},
    "group4": {
    "name": "failed",
    "count": 23,
    "percentage": 2
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.973",
        "ok": "8.766",
        "ko": "0.207"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "359",
        "ok": "359",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "404",
        "ok": "404",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "percentiles1": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "percentiles2": {
        "total": "413",
        "ok": "413",
        "ko": "-"
    },
    "percentiles3": {
        "total": "472",
        "ok": "472",
        "ko": "-"
    },
    "percentiles4": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 50,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "46",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "272",
        "ok": "272",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "33891",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "9635",
        "ok": "5256",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "16466",
        "ok": "7412",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2140",
        "ok": "1960",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "7606",
        "ok": "4150",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "18167",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "33014",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 4
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 41,
    "percentage": 82
},
    "group4": {
    "name": "failed",
    "count": 4,
    "percentage": 8
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.414",
        "ko": "0.036"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "96",
        "ok": "96",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2561",
        "ok": "2561",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "402",
        "ok": "402",
        "ko": "-"
    },
    "percentiles1": {
        "total": "165",
        "ok": "165",
        "ko": "-"
    },
    "percentiles2": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "percentiles3": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2104",
        "ok": "2104",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 92,
    "percentage": 96
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.865",
        "ok": "0.865",
        "ko": "-"
    }
}
    },"req_solid-css-8f91a": {
        type: "REQUEST",
        name: "solid.css",
path: "solid.css",
pathFormatted: "req_solid-css-8f91a",
stats: {
    "name": "solid.css",
    "numberOfRequests": {
        "total": "96",
        "ok": "96",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "37",
        "ok": "37",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3210",
        "ok": "3210",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "percentiles1": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles2": {
        "total": "302",
        "ok": "302",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1002",
        "ok": "1002",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2519",
        "ok": "2519",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 89,
    "percentage": 93
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.865",
        "ok": "0.865",
        "ko": "-"
    }
}
    },"req_solid-auth-clie-301ec": {
        type: "REQUEST",
        name: "solid-auth-client.bundle.js",
path: "solid-auth-client.bundle.js",
pathFormatted: "req_solid-auth-clie-301ec",
stats: {
    "name": "solid-auth-client.bundle.js",
    "numberOfRequests": {
        "total": "46",
        "ok": "46",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "270",
        "ok": "270",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3520",
        "ok": "3520",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "673",
        "ok": "673",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "705",
        "ok": "705",
        "ko": "-"
    },
    "percentiles1": {
        "total": "392",
        "ok": "392",
        "ko": "-"
    },
    "percentiles2": {
        "total": "565",
        "ok": "565",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2571",
        "ok": "2571",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3119",
        "ok": "3119",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 38,
    "percentage": 83
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 11
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.414",
        "ok": "0.414",
        "ko": "-"
    }
}
    },"req_auth-buttons-js-47a35": {
        type: "REQUEST",
        name: "auth-buttons.js",
path: "auth-buttons.js",
pathFormatted: "req_auth-buttons-js-47a35",
stats: {
    "name": "auth-buttons.js",
    "numberOfRequests": {
        "total": "46",
        "ok": "46",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "156",
        "ok": "156",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3206",
        "ok": "3206",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "506",
        "ok": "506",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "662",
        "ok": "662",
        "ko": "-"
    },
    "percentiles1": {
        "total": "257",
        "ok": "257",
        "ko": "-"
    },
    "percentiles2": {
        "total": "426",
        "ok": "426",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2260",
        "ok": "2260",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2868",
        "ok": "2868",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 40,
    "percentage": 87
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 9
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.414",
        "ok": "0.414",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "146",
        "ok": "146",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1555",
        "ok": "1555",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "268",
        "ok": "268",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "227",
        "ok": "227",
        "ko": "-"
    },
    "percentiles1": {
        "total": "187",
        "ok": "187",
        "ko": "-"
    },
    "percentiles2": {
        "total": "221",
        "ok": "221",
        "ko": "-"
    },
    "percentiles3": {
        "total": "638",
        "ok": "638",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1111",
        "ok": "1111",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 49,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2510",
        "ok": "2510",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "410",
        "ok": "410",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "688",
        "ok": "688",
        "ko": "-"
    },
    "percentiles1": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "percentiles2": {
        "total": "240",
        "ok": "240",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2085",
        "ok": "2085",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2486",
        "ok": "2486",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 41,
    "percentage": 82
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9,
    "percentage": 18
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-2-redir-733ac": {
        type: "REQUEST",
        name: "request_2 Redirect 1",
path: "request_2 Redirect 1",
pathFormatted: "req_request-2-redir-733ac",
stats: {
    "name": "request_2 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "55",
        "ok": "55",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3054",
        "ok": "3054",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "421",
        "ok": "421",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "660",
        "ok": "660",
        "ko": "-"
    },
    "percentiles1": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "percentiles2": {
        "total": "508",
        "ok": "508",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1957",
        "ok": "1957",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2536",
        "ok": "2536",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 42,
    "percentage": 84
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 12
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2757",
        "ok": "2757",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1390",
        "ok": "1390",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "927",
        "ok": "927",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1129",
        "ok": "1129",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2501",
        "ok": "2501",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2678",
        "ok": "2678",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2736",
        "ok": "2736",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 16,
    "percentage": 32
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 28
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 20,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-3-redir-2cb6e": {
        type: "REQUEST",
        name: "request_3 Redirect 1",
path: "request_3 Redirect 1",
pathFormatted: "req_request-3-redir-2cb6e",
stats: {
    "name": "request_3 Redirect 1",
    "numberOfRequests": {
        "total": "50",
        "ok": "48",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "80",
        "ok": "80",
        "ko": "462"
    },
    "maxResponseTime": {
        "total": "2221",
        "ok": "2221",
        "ko": "463"
    },
    "meanResponseTime": {
        "total": "480",
        "ok": "480",
        "ko": "463"
    },
    "standardDeviation": {
        "total": "553",
        "ok": "564",
        "ko": "1"
    },
    "percentiles1": {
        "total": "244",
        "ok": "241",
        "ko": "463"
    },
    "percentiles2": {
        "total": "558",
        "ok": "590",
        "ko": "463"
    },
    "percentiles3": {
        "total": "2204",
        "ok": "2204",
        "ko": "463"
    },
    "percentiles4": {
        "total": "2217",
        "ok": "2217",
        "ko": "463"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 42,
    "percentage": 84
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 2,
    "percentage": 4
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.432",
        "ko": "0.018"
    }
}
    },"req_request-3-redir-9f15c": {
        type: "REQUEST",
        name: "request_3 Redirect 2",
path: "request_3 Redirect 2",
pathFormatted: "req_request-3-redir-9f15c",
stats: {
    "name": "request_3 Redirect 2",
    "numberOfRequests": {
        "total": "48",
        "ok": "48",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "85",
        "ok": "85",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3257",
        "ok": "3257",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "601",
        "ok": "601",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "720",
        "ok": "720",
        "ko": "-"
    },
    "percentiles1": {
        "total": "350",
        "ok": "350",
        "ko": "-"
    },
    "percentiles2": {
        "total": "468",
        "ok": "468",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2390",
        "ok": "2390",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2929",
        "ok": "2929",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 42,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 13
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.432",
        "ok": "0.432",
        "ko": "-"
    }
}
    },"req_request-3-redir-08bb3": {
        type: "REQUEST",
        name: "request_3 Redirect 3",
path: "request_3 Redirect 3",
pathFormatted: "req_request-3-redir-08bb3",
stats: {
    "name": "request_3 Redirect 3",
    "numberOfRequests": {
        "total": "48",
        "ok": "48",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2354",
        "ok": "2354",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "547",
        "ok": "547",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "544",
        "ok": "544",
        "ko": "-"
    },
    "percentiles1": {
        "total": "353",
        "ok": "353",
        "ko": "-"
    },
    "percentiles2": {
        "total": "484",
        "ok": "484",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1877",
        "ok": "1877",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2320",
        "ok": "2320",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 40,
    "percentage": 83
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.432",
        "ok": "0.432",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "50",
        "ok": "33",
        "ko": "17"
    },
    "minResponseTime": {
        "total": "293",
        "ok": "293",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "35383",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "24258",
        "ok": "5845",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "26655",
        "ok": "8905",
        "ko": "0"
    },
    "percentiles1": {
        "total": "7297",
        "ok": "1935",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "60001",
        "ok": "7262",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "25809",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "35360",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 20
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 20,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 17,
    "percentage": 34
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.297",
        "ko": "0.153"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "33",
        "ok": "33",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "166",
        "ok": "166",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3445",
        "ok": "3445",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "722",
        "ok": "722",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "682",
        "ok": "682",
        "ko": "-"
    },
    "percentiles1": {
        "total": "557",
        "ok": "557",
        "ko": "-"
    },
    "percentiles2": {
        "total": "879",
        "ok": "879",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1813",
        "ok": "1813",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3092",
        "ok": "3092",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 22,
    "percentage": 67
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 18
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 15
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.297",
        "ok": "0.297",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "33",
        "ok": "33",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "361",
        "ok": "361",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4399",
        "ok": "4399",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1114",
        "ok": "1114",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "864",
        "ok": "864",
        "ko": "-"
    },
    "percentiles1": {
        "total": "843",
        "ok": "843",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1391",
        "ok": "1391",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2703",
        "ok": "2703",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4103",
        "ok": "4103",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 15,
    "percentage": 45
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 18
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 12,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.297",
        "ok": "0.297",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "167",
        "ok": "167",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "32896",
        "ok": "32896",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2938",
        "ok": "2938",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5240",
        "ok": "5240",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1316",
        "ok": "1316",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3411",
        "ok": "3411",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8782",
        "ok": "8782",
        "ko": "-"
    },
    "percentiles4": {
        "total": "25035",
        "ok": "25035",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 18,
    "percentage": 36
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 26,
    "percentage": 52
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1897",
        "ok": "1897",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "632",
        "ok": "632",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "430",
        "ok": "430",
        "ko": "-"
    },
    "percentiles1": {
        "total": "431",
        "ok": "431",
        "ko": "-"
    },
    "percentiles2": {
        "total": "953",
        "ok": "953",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1438",
        "ok": "1438",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1753",
        "ok": "1753",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 33,
    "percentage": 66
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 22
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 12
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2633",
        "ok": "2633",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "623",
        "ok": "623",
        "ko": "-"
    },
    "percentiles1": {
        "total": "580",
        "ok": "580",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1208",
        "ok": "1208",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2112",
        "ok": "2112",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2515",
        "ok": "2515",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 29,
    "percentage": 58
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 8,
    "percentage": 16
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 13,
    "percentage": 26
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.45",
        "ok": "0.45",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
